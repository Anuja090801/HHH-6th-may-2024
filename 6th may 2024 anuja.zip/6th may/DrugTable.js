document.addEventListener("DOMContentLoaded", function() {
    var searchButton = document.getElementById("searchButton");

    searchButton.addEventListener("click", function() {
        search();
    });

    function search() {
        var selectedDisease = document.getElementById("categorySelect").value;
        var table = document.getElementById("resultTable");
        var resultBody = document.getElementById("resultBody");
        var container = document.querySelector(".container");

        // Clear previous results
        resultBody.innerHTML = "";
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Fetch data based on selected disease
        // Example data
        var data = [];

        switch(selectedDisease.toLowerCase()) {
            case "breast cancer":
                data = [
                    { Mild: "Tamoxifen", Chronic: "Doxorubicin" },
                    { Mild: "Letrozole", Chronic: "Paclitaxel" },
                    { Mild: "Lapatinib ", Chronic: "Capecitabine" },
                    { Mild: "Neratinib ", Chronic: "Cyclophosphamide" },
                    { Mild: "Palbociclib ", Chronic: "Carboplatin " },
                    { Mild: "Abemaciclib ", Chronic: "Evista " },
                    { Mild: "Pertuzumab ", Chronic: "Epirubicin " },
                    { Mild: "Trastuzumab ", Chronic: "Fluorouracil " },
                ];
                break;
                case "pcod":
                    data = [
                      { Mild: "Clomiphene ", Chronic: "Acarbose" },
                      { Mild: " Eflornithine", Chronic: "Desogestrel " },
                      { Mild: " Metformin ", Chronic: "Finasteride" },
                      { Mild: " Metformin ", Chronic: "Flutamide" },
                      { Mild: "Spironolactone", Chronic: "Latrozole" },
                      { Mild: " Liraglutide", Chronic: " Sibutramine " },
                      { Mild: " Pioglitazone", Chronic: "Drospirenone " },
                      { Mild: "Rosiglitazone ", Chronic: "Ethinylestradiol Plus Levonorgestrel" }
                        ];
                    break;
                  case "thyroid":
                    data = [
                      { Mild: "Levothyroxine ", Chronic: "methimazole  " },
                      { Mild: " liothyronine ", Chronic: "propylthiouracil " },
                      { Mild: "Tirosint ", Chronic: " Vandetanib" },
                      { Mild: "Pazopanib", Chronic: "Liotrex " },
                      { Mild: "Carbimazole ", Chronic: "Triiodothyronine" },
                      { Mild: " Dexamethasone", Chronic: " Thyroxin " },
                      { Mild: "Sunitinib ", Chronic: "Calcitonin  " },
                      { Mild: "Thyrotropin Alfa  ", Chronic: "Sorafenib " },
                        ];
                    break;
                  case "cervical cancer":
                    data = [
                      { Mild: "Acetaminophen", Chronic: "Cisplatin" },
                      { Mild: " Ibuprofen  ", Chronic: "Carboplatin" },
                      { Mild: " Naproxen  ", Chronic: "Paclitaxel" },
                      { Mild: " Ondansetron  ", Chronic: "Topotecan" },
                      { Mild: "Metoclopramide  ", Chronic: "Gemcitabine" },
                      { Mild: "Dexamethasone ", Chronic: "Oxaliplati " },
                      { Mild: " Lorazepam   ", Chronic: " Docetaxel" },
                      { Mild: " Diphenhydramine  ", Chronic: " Irinotecan" },
                        ];
                    break;
                  case "uterine fibroids":
                    data = [
                      { Mild: "Halofuginone ", Chronic: "Anastrozole " },
                      { Mild: "Pirfenidone ", Chronic: "Myfembree" },
                      { Mild: "acetaminophen ", Chronic: "Ulipristal Acetate" },
                      { Mild: "mifepristone  ", Chronic: "Oriahnn" },
                      { Mild: "fadrozole ", Chronic: " Leuprolide " },
                      { Mild: "asoprisnil", Chronic: " Ulipristal" },
                      { Mild: "vilaprisan ", Chronic: " Goserelin" },
                      { Mild: "Tranexamic acid ", Chronic: " Triplorelin" },
                        ];
                    break;
                  default:
                    break;
        }

        // Populate table with fetched data
        for (var i = 0; i < data.length; i++) {
            var row = document.createElement("tr");
            var mildLink = createDrugLink(data[i].Mild);
            var chronicLink = createDrugLink(data[i].Chronic);
            row.innerHTML = "<td>" + mildLink + "</td><td>" + chronicLink + "</td>";
            resultBody.appendChild(row);
        }

        // Show the table
        table.style.display = "table";
    }

        // Function to create a drug link
    function createDrugLink(drugName) {
        return "<a href='DrugDetails/" + drugName + ".html' style='text-decoration: none; color: black;'>" + drugName + "</a>";
    }
});
